# TvBox 配置

所有数据均来自于网络，不保证可用性

原始数据来源：https://github.com/tv-player/TvBox

因电视对GitHub访问问题，所以将配置中的GitHub换成镜像源

本次更新时间为：2023-03-10 05:13:31

如果有必要手动输入建议使用短链如：[http://gg.gg/](http://gg.gg/)，[https://suowo.cn/](https://suowo.cn/)，[https://dlj.li/](https://dlj.li/) 等

删除列表，请复制项目后自行对tv目录下的数字目录内的文件进行镜像使用

