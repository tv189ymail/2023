## 更新说明：   
mk1.conf为iOS平台***MK播放器 for M3U8*** 的订阅链接。  
https://apps.apple.com/cn/app/mkplayer-for-m3u8/id1455832781

lt.txt为Android平台***骆驼壳网络接口版V2.3***的订阅链接。   

## ***订阅格式***  
## MK播放器  

[Group]  
groupName=国内  
aaa,http://www.abc.com/a.m3u8  

[Group]  
groupName=国外  
bbb,http://www.abc.com/b.m3u8  

## M3U分组  
#EXTM3U  
#EXTINF:-1 tvg-id="" tvg-name="" tvg-language="Chinese" tvg-logo="https://a.a.com/a.png" tvg-country="CN" tvg-url="" group-title="国内",东方卫视  
http://0.0.0.0/0.m3u8


## ***Android端APP***  
骆驼网络接口版V2.3(增加支持了网络订阅功能，支持多种格式直播源，支持遥控器及触屏)   


TiviMate IPTV Player(支持合并分组可一个订阅链接实现多个分类，支持遥控器)  
Free版只支持单链接，Pro版支持多链接。  
https://play.google.com/store/apps/details?id=ar.tvplayer.tv  
https://t.me/tivimate  
	
GSE SMART IPTV(支持订阅,功能全面，有TV模式，操作稍繁琐，支持rtsp、rtmp，有内购去广告) 
https://play.google.com/store/apps/details?id=com.gsetech.smartiptv

IPTV(遥控器非完美支持，无内置播放器，需加载第三方播放器播放，如MX Player)  
https://play.google.com/store/apps/details?id=ru.iptvremote.android.iptv

LAZY IPTV（可订阅,遥控器非完美支持，免费有广告）  
https://play.google.com/store/apps/details?id=com.lazycatsoftware.iptv

Perfect Player IPTV(支持遥控器)  
https://play.google.com/store/apps/details?id=com.niklabs.pp

其它：  
骆驼网络接口版09_08TVBUS记忆播放修复V2.3.apk，超级直播自定义_1.4.4，新版世纪TV自定义等。

## ***iOS端APP***

MK播放器 for M3U8(现在唯一在用，支持单链接多分组简洁订阅链接，格式简单手机端也好维护，画中画、后台播放、分组隐藏等，功能全面，有公共订阅源自动维护，操作、使用体验好)  
https://itunes.apple.com/cn/app/mk%E6%92%AD%E6%94%BE%E5%99%A8-for-m3u8/id1455832781

GSE SMART IPTV(功能全面，操作稍繁琐，支持rtsp、rtmp，有内购)  
https://itunes.apple.com/us/app/gse-smart-iptv/id1028734023?mt=8

IPTV-M3U PLAYER-IP TELEVISION(功能简单，默认自动支持支持rtsp、rtmp)  
https://itunes.apple.com/cn/app/iptv-m3u-player-ip-television/id1368623943?mt=8

GoTV - M3U IPTV Player(开启额外的解码器选项可以支持rtsp、rtmp,可自动更新订阅)  
https://itunes.apple.com/cn/app/gotv-m3u-iptv-player/id1271283728?mt=8

Flex IPTV  
https://itunes.apple.com/cn/app/flex-iptv/id1182930255?mt=8

NetTV - IPTV Player  
https://itunes.apple.com/cn/app/nettv-iptv-player/id1369298362?mt=8

IPTV Player: play m3u playlist  
https://itunes.apple.com/cn/app/iptv-player-play-m3u-playlist/id1303327384?mt=8

## ***利器***
Thor HTTP 抓包嗅探分析&接口调试&网络协议（除了抓包，更可以在抓取普通链接仍无法播放的情况下，生成包含认证信息的“shu链接”供MK播放器上播放）  
https://apps.apple.com/cn/app/id1210562295

猫抓（Chrome浏览器里提取直链地址并下载）  
https://chrome.google.com/webstore/detail/%E7%8C%AB%E6%8A%93/jfedfbgedapdagkghmgibemcoggfppbb

Stream Video Downloader（M3U8下载成MP4）  
https://chrome.google.com/webstore/detail/stream-video-downloader/imkngaibigegepnlckfcbecjoilcjbhf

列表制作转换工具TeleList-2.4.1（PC端）  
https://guihet.com/tvlive-telelist.html

IPTV Checker 2.06(直链有效性检测，超高效率)  
https://tiny-tools.com/download/iptv-checker/

M3U8批量下载器V1.4.2 by逍遥一仙  
https://www.52pojie.cn/thread-785996-1-1.html
