muban.海螺3.二级.desc = '.hl-text-conch&&Text';
var rule = Object.assign(muban.海螺3,{
    title:'AnFuns动漫',
    host:'https://www.anfuns.cc',
    cate_exclude: '最新|排行',
    url:'/type/fyclass-fypage.html',
    searchUrl:'/search/page/fypage/wd/**.html',
});