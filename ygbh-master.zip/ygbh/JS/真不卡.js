muban.首图2.二级.tabs = '.stui-pannel__head.bottom-line.active.clearfix h3';
var rule = Object.assign(muban.首图2,{
title:'真不卡',
host:'https://www.zbkk.net',
url:'/vodshow/fyclass--------fypage---.html',
class_parse:'.stui-header__menu .dropdown li:gt(0):lt(5);a&&Text;a&&href;.*/(.*?).html',
// searchUrl:'/vodsearch/**----------fypage---.html',
});