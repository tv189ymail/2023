muban.首图2.二级.tabs = '.nav-tabs.dpplay&&li';
var rule = Object.assign(muban.首图2,{
    title:'007影视',
    ali_token:'{{ali_token}}',
    bili_cookie:'{{bili_cookie}}',
    host:'https://www.007ts.me',
    url:'/channel/fyclass-fypage.html',
    searchUrl:'/search/**----------fypage---.html',
});